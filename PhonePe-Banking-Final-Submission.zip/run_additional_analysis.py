"""Run a safe, schema-independent overview of CSV files in data/."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "outputs"
REPORT_DIR = ROOT / "reports"
OUT_DIR.mkdir(exist_ok=True)
REPORT_DIR.mkdir(exist_ok=True)

def main():
    csv_files = sorted(DATA_DIR.glob("*.csv"))
    if not csv_files:
        print(f"No CSV files found in: {DATA_DIR}")
        print("Place your project CSV datasets in the data folder and run again.")
        return

    sections = ["PHONEPE BANKING DATASET OVERVIEW", "=" * 40]
    for path in csv_files:
        try:
            df = pd.read_csv(path)
            sections += [
                f"\nFILE: {path.name}",
                f"Rows: {len(df)}",
                f"Columns: {len(df.columns)}",
                "Column names: " + ", ".join(map(str, df.columns)),
                "\nMissing values:",
                df.isna().sum().to_string(),
                "\nNumeric summary:",
                df.describe(include="number").round(2).to_string()
                if not df.select_dtypes(include="number").empty else "No numeric columns."
            ]
            print(f"Analysed {path.name}: {df.shape[0]} rows x {df.shape[1]} columns")
        except Exception as exc:
            sections.append(f"\nFILE: {path.name}\nCould not read file: {exc}")

    report = "\n".join(sections)
    report_path = REPORT_DIR / "dataset_overview.txt"
    report_path.write_text(report, encoding="utf-8")
    print(f"\nReport saved to: {report_path}")

if __name__ == "__main__":
    main()
