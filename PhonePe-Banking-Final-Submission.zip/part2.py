from capstone import mainparts
mainparts(2)
