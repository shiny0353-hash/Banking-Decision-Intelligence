"""Optional transaction metrics; detects common amount column names."""
import pandas as pd

AMOUNT_CANDIDATES = ("amount", "transaction_amount", "txn_amount", "value")

def summarize_amounts(df: pd.DataFrame):
    column_lookup = {str(c).strip().lower(): c for c in df.columns}
    amount_col = next((column_lookup[name] for name in AMOUNT_CANDIDATES
                       if name in column_lookup), None)
    if amount_col is None:
        return None
    values = pd.to_numeric(df[amount_col], errors="coerce").dropna()
    if values.empty:
        return {"amount_column": str(amount_col), "message": "No numeric values found."}
    return {
        "amount_column": str(amount_col),
        "total": float(values.sum()),
        "average": float(values.mean()),
        "median": float(values.median()),
        "minimum": float(values.min()),
        "maximum": float(values.max()),
    }
