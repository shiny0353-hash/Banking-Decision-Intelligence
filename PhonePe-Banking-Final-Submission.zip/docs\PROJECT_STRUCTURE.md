# Suggested project structure

Keep your existing `part1.py`–`part4.py`, `generate_data.py`, `data/`, and `outputs/`.
Add the following only if they do not already exist:

- `config.py` — common project paths
- `run_additional_analysis.py` — creates a general CSV dataset overview
- `analysis/` — reusable analysis utilities
- `visualizations/` — charts
- `reports/` — written outputs
- `docs/` — project documentation

This extension is additive. It is not a replacement for your existing project files.
