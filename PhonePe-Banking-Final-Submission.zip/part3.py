from capstone import mainparts
mainparts(3)
