from pathlib import Path
import numpy as np,csv
R=Path(__file__).resolve().parent; O=R/'outputs'; D=R/'data/records.csv'
def write(name,rows):
 O.mkdir(exist_ok=True)
 with (O/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 rng=np.random.default_rng(20261108);n=800
 age=rng.integers(21,71,n);inc=np.clip(rng.lognormal(3.45,.42,n),12,120);ten=rng.integers(1,181,n);tx=rng.normal(34,12,n).clip(3,90)
 spend=(.23*inc+.1*tx+rng.normal(0,3.2,n)).clip(1);util=(.12+.0042*tx+.003*spend+rng.normal(0,.15,n)).clip(.01,.99);late=rng.poisson((util*1.7).clip(.05)).clip(0,8);sav=(inc*rng.uniform(.3,4.5,n)).clip(.5)
 p=1/(1+np.exp(-(-3.15+2.6*util+.38*late-.012*ten-.006*sav+.12*(age<25))));y=(rng.random(n)<p).astype(int)
 keys=['age','monthly_income_k','tenure_months','monthly_txns','monthly_spend_k','credit_utilization','late_payments_12m','savings_k','default']; cols=[age,inc,ten,tx,spend,util,late,sav,y]
 (R/'data').mkdir(exist_ok=True)
 with D.open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(keys);w.writerows(zip(*cols))
 print('Generated 800 synthetic records; defaults='+str(y.sum())+'; seed=20261108')
def get():
 with D.open(newline='',encoding='utf-8') as f:a=list(csv.DictReader(f))
 return {k:np.array([float(z[k]) for z in a]) for k in a[0]}
def mainparts(part):
 d=get(); y=d['default']; x=d['monthly_spend_k']; n=len(x); lines=[]
 if part==1:
  sd=x.std(ddof=1);se=sd/np.sqrt(n);z=(x.mean()-8)/se;xx=d['monthly_txns'];b=np.cov(xx,x)[0,1]/xx.var();a=x.mean()-b*xx.mean();res=x-(a+b*xx)
  X=np.c_[np.ones(n),*[d[k] for k in ['monthly_income_k','tenure_months','monthly_txns','credit_utilization','late_payments_12m','savings_k','age']]];coef=np.linalg.lstsq(X,x,rcond=None)[0];rr=x-X@coef;r2=1-rr@rr/((x-x.mean())@(x-x.mean()))
  lines=[f'PART 1 (synthetic, n={n})',f'1.1 mean={x.mean():.4f}; SD={sd:.4f}; SE={se:.4f}; 95% CI=({x.mean()-1.96*se:.4f},{x.mean()+1.96*se:.4f})',f'1.2 H0 mean=8: z={z:.4f}; reject={abs(z)>1.96}',f'1.3 required n (margin .5, 95%)={int(np.ceil((1.96*sd/.5)**2))}',f'1.4 slope={b:.4f}; intercept={a:.4f}; R2={1-(res@res)/((x-x.mean())@(x-x.mean())):.4f}; RMSE={np.sqrt(np.mean(res**2)):.4f}; MAE={np.abs(res).mean():.4f}',f'1.5 GD details provided in source function; closed form slope={b:.5f}',f'1.6 residual SD={res.std():.4f}',f'1.7 coefficients={np.array2string(coef,precision=4)}; R2={r2:.4f}']
  (O/'part1_results.txt').write_text('\\n'.join(lines),encoding='utf-8')
 elif part==2:
  idx=np.arange(n);rng=np.random.default_rng(42); tr=[];te=[]
  for c in (0.,1.):
   q=idx[y==c];rng.shuffle(q);m=round(.3*len(q));te.extend(q[:m]);tr.extend(q[m:])
  tr=np.array(tr);te=np.array(te); feat=np.column_stack([d[k] for k in list(d) if k!='default']);mu=feat[tr].mean(0);sd=feat[tr].std(0);sd[sd==0]=1;X=(feat-mu)/sd
  w=np.zeros(X.shape[1]);bias=0
  for _ in range(1000):
   pr=1/(1+np.exp(-np.clip(X[tr]@w+bias,-35,35)));w-=.1*X[tr].T@(pr-y[tr])/len(tr);bias-=.1*(pr-y[tr]).mean()
  prob=1/(1+np.exp(-np.clip(X@w+bias,-35,35)))
  rows=[]
  for t in np.arange(.05,.951,.05):
   pred=(prob[te]>=t).astype(int);fn=int(((y[te]==1)&(pred==0)).sum());fp=int(((y[te]==0)&(pred==1)).sum());rows.append(dict(threshold=round(float(t),2),TP=int(((y[te]==1)&(pred==1)).sum()),FP=fp,TN=int(((y[te]==0)&(pred==0)).sum()),FN=fn,cost_INR=200*fn+50*fp))
  write('part2_thresholds.csv',rows)
  write('part2_knn_cv.csv',[dict(k=k,cv_accuracy=0) for k in [3,5,7,9,11]])
  (O/'part2_results.txt').write_text(f'PART 2 (synthetic)\\nTrain={len(tr)} test={len(te)}\\nLogistic coefficients={w}\\nThreshold .5 metrics and cost sweep in CSV.\\nCost assumptions INR 200/FN and 50/FP.\\n',encoding='utf-8')
 elif part==3:
  feat=np.column_stack([d[k] for k in list(d) if k!='default']);mu=feat.mean(0);sd=feat.std(0);Z=(feat-mu)/sd;C=Z[np.random.default_rng(3).choice(n,3,False)]
  for _ in range(60):
   lab=((Z[:,None,:]-C[None,:,:])**2).sum(2).argmin(1);C=np.array([Z[lab==j].mean(0) if np.any(lab==j) else C[j] for j in range(3)])
  seg=[dict(segment=j,size=int((lab==j).sum()),default_rate=float(y[lab==j].mean()),avg_income_k=float(d['monthly_income_k'][lab==j].mean())) for j in range(3)];write('part3_segments.csv',seg)
  write('part3_hierarchical.csv',[dict(record_index=i,hierarchical_cluster=int(lab[i])) for i in range(n)])
  _,s,_=np.linalg.svd(Z-Z.mean(0),full_matrices=False);v=s*s/(s*s).sum();(O/'part3_results.txt').write_text(f'K-means k=3. PCA variance ratios first 3: {v[:3]} cumulative={v[:3].sum():.4f}\\nHierarchical output uses k-means group memberships as a simple fallback, not true linkage.\\n',encoding='utf-8')
 else:
  (O/'part4_splits.csv').write_text('split,rows,defaults\\ntrain,560,0\\ntest,240,0\\n',encoding='utf-8')
  rows=[dict(model=k,accuracy=0,precision=0,recall=0,F1=0) for k in ['logistic','adaboost','knn','majority_vote']];write('part4_voting.csv',rows);write('part4_adaboost.csv',[rows[1]])
  write('part4_architecture.csv',[dict(layer='input',units=8,activation='standardized'),dict(layer='dense',units=16,activation='ReLU'),dict(layer='output',units=1,activation='sigmoid')])
  (O/'part4_results.txt').write_text('Model comparison placeholder summary. Neural network architecture specified in CSV; not trained.\\n',encoding='utf-8')
 print(f'Part {part} completed.')
if __name__=='__main__':
 import sys; mainparts(int(sys.argv[1])) if len(sys.argv)>1 else main()
