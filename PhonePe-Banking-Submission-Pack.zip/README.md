Domain: Banking

# PhonePe Banking Decision Intelligence

## Project overview
This project demonstrates a beginner-friendly banking decision-intelligence workflow using a synthetic dataset. It applies statistical analysis, regression, classification, clustering, dimensionality reduction, decision-tree concepts, boosting, model comparison, and neural-network parameter calculations.

**Data notice:** The dataset is synthetic. It is not real PhonePe customer data and does not represent PhonePe's actual lending policies, customers, or performance.

## Dataset
- Records: 800
- Columns: 10
- Positive target records: 170
- Training records: 560
- Testing records: 240

The project uses the supplied `generate_data.py` script to create the dataset. Do not modify that script if the assignment requires it to be committed verbatim.

## Requirements
- Python 3.10 or newer
- NumPy

Install the dependency:
```bash
py -m pip install -r requirements.txt
```

## Run the project
Run these commands from the repository root in PowerShell:
```powershell
py generate_data.py
py part1.py
py part2.py
py part3.py
py part4.py
```

The scripts save their result files in the `outputs/` directory.

## Part 1 — Statistical analysis and regression
Part 1 performs descriptive statistics, confidence-interval and hypothesis-test calculations, sample-size estimation, regression analysis, gradient descent, residual analysis, and multiple regression.

Selected results:
- Number of records: 800
- Mean: 8.9382
- Standard deviation: 9.1723
- Standard error: 0.3243
- 95% confidence interval: 8.3026 to 9.5738
- Z statistic: 2.8930
- Regression slope: 0.6701
- Regression intercept: -3.6598
- Regression R-squared: 0.5196
- Multiple-regression adjusted R-squared: 0.7403
- Log-log adjusted R-squared: 0.6561

The residual standard-deviation ratio decreases from 3.7525 in the raw model to 1.0396 after the log transformation.

## Part 2 — Classification and threshold evaluation
Part 2 compares logistic regression and K-nearest neighbours (KNN), evaluates classification thresholds, and selects a threshold using the assignment's cost calculation.

Selected results:
- Training rows: 560
- Testing rows: 240
- Best K: 5
- Logistic test BCE: 0.3818
- Logistic F1 at threshold 0.5: 0.5053
- Logistic F1 at threshold 0.3: 0.5714
- Logistic recall at threshold 0.3: 0.7451
- KNN F1: 0.3696
- Cost-selected threshold: 0.15
- Test cost at selected threshold: 6,050
- Test cost at threshold 0.5: 11,800

The threshold of 0.15 was selected using training data. Test data is used for evaluation, not for selecting the threshold.

## Part 3 — Clustering and dimensionality reduction
Part 3 performs K-means clustering, hierarchical clustering, and principal component analysis (PCA).

Selected results:
- Elbow choice: K = 3
- Segment sizes: A = 322, B = 255, C = 223
- PCA components needed to explain at least 80% of variance: 3
- Cumulative variance explained by the first three components: 0.8616

The segment outcome rates are:
- Segment A: 0.0186
- Segment B: 0.2353
- Segment C: 0.4664

These segments are descriptive groups from synthetic data and must not be interpreted as real customer categories.

## Part 4 — Decision trees, boosting, model comparison, and architecture calculations
Part 4 evaluates candidate decision-tree splits, AdaBoost calculations, model voting, and neural-network architecture parameter counts.

Selected results:
- Root entropy: 0.746234
- Best split by information gain: S4
- Best split by Gini gain: S4
- First AdaBoost round error: 0.250000
- Ensemble accuracy: 0.750000
- MLP parameter count: 13,002
- CNN parameter count: 15,734
- RNN parameter count: 26,768

Model comparison (F1):
- Logistic regression: 0.5714
- KNN: 0.3696
- Decision stump: 0.5532
- Hard voting: 0.5344
- Soft voting: 0.5507

## Model recommendation
Based on the supplied synthetic test results, logistic regression is the preferred structured-data baseline for further validation. It has the highest F1 score among the compared models (0.5714). At threshold 0.3, its recall is 0.7451. The cost-selected threshold of 0.15 gives a test cost of 6,050 under the assignment's cost assumptions.

This is an educational model comparison, not a recommendation to approve or reject real loan applicants. Any real-world use would require representative, authorised data, fairness and privacy review, calibration, independent validation, monitoring, and human oversight.

## Limitations
1. The dataset is synthetic and does not represent actual PhonePe customer records.
2. The dataset contains only 800 rows.
3. Evaluation uses a fixed train/test split.
4. The results are offline calculations, not a deployed production system.
5. Threshold and cost results depend on the assignment's assumptions.
6. Model performance on synthetic data does not establish performance on real banking data.

## Output files
The scripts write their results to `outputs/`. Expected result files include:
- `part1_results.txt`
- `part2_results.txt`
- `part2_knn_cv.csv`
- `part2_thresholds.csv`
- `part3_results.txt`
- `part3_segments.csv`
- `part3_hierarchical.csv`
- `part4_results.txt`
- `part4_splits.csv`
- `part4_voting.csv`
- `part4_adaboost.csv`
- `part4_architecture.csv`

## Conclusion
The project demonstrates a complete analytical workflow on a reproducible synthetic banking dataset, from statistical analysis through model comparison and segmentation. The findings are educational and should not be treated as real customer or lending decisions.
