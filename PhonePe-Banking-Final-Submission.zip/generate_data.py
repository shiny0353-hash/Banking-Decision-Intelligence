from pathlib import Path
import csv,numpy as np
R=Path(__file__).resolve().parent
def main():
 r=np.random.default_rng(20261108); n=800
 age=r.integers(21,71,n); income=np.clip(r.lognormal(3.45,.42,n),12,120); tenure=r.integers(1,181,n); tx=r.normal(34,12,n).clip(3,90)
 spend=(.23*income+.1*tx+r.normal(0,3.2,n)).clip(1); util=(.12+.0042*tx+.003*spend+r.normal(0,.15,n)).clip(.01,.99)
 late=r.poisson((util*1.7).clip(.05)).clip(0,8); savings=(income*r.uniform(.3,4.5,n)).clip(.5)
 p=1/(1+np.exp(-(-3.15+2.6*util+.38*late-.012*tenure-.006*savings+.12*(age<25)))); default=(r.random(n)<p).astype(int)
 cols=[age,income,tenure,tx,spend,util,late,savings,default]; names=['age','monthly_income_k','tenure_months','monthly_txns','monthly_spend_k','credit_utilization','late_payments_12m','savings_k','default']
 (R/'data').mkdir(exist_ok=True)
 with (R/'data/records.csv').open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f); w.writerow(names); w.writerows([[int(v) if i in (0,2,6,8) else f'{v:.6f}' for i,v in enumerate(row)] for row in zip(*cols)])
 print(f'Generated {n} synthetic records; defaults={default.sum()}; seed=20261108')
if __name__=='__main__': main()
