from capstone import mainparts
mainparts(4)
