"""Configuration for PhonePe Banking Decision Intelligence."""
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
REPORT_DIR = PROJECT_ROOT / "reports"
CHART_DIR = PROJECT_ROOT / "visualizations"

for folder in (OUTPUT_DIR, REPORT_DIR, CHART_DIR):
    folder.mkdir(parents=True, exist_ok=True)
