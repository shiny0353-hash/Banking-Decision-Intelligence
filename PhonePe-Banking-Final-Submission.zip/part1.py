from capstone import mainparts
mainparts(1)
