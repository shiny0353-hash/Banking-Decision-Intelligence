from pathlib import Path
import csv,numpy as np
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'outputs'; DATA=ROOT/'data/records.csv'
def load():
 with DATA.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 return {k:np.array([float(x[k]) for x in rows]) for k in rows[0]}
def split(y,seed=42):
 r=np.random.default_rng(seed); a=[]; b=[]
 for c in np.unique(y):
  ix=np.flatnonzero(y==c); r.shuffle(ix); n=round(len(ix)*.3); b.extend(ix[:n]); a.extend(ix[n:])
 return np.array(sorted(a)),np.array(sorted(b))
def scale(x):
 m=x.mean(0); s=x.std(0); s[s==0]=1; return m,s
def sig(x): return 1/(1+np.exp(-np.clip(x,-35,35)))
def metrics(y,p):
 tp=int(((y==1)&(p==1)).sum()); fp=int(((y==0)&(p==1)).sum()); tn=int(((y==0)&(p==0)).sum()); fn=int(((y==1)&(p==0)).sum())
 d=lambda a,b:a/b if b else 0.; q=d(tp,tp+fp); z=d(tp,tp+fn)
 return dict(TP=tp,FP=fp,TN=tn,FN=fn,accuracy=d(tp+tn,len(y)),precision=q,recall=z,F1=d(2*q*z,q+z))
def csvout(name,rows):
 OUT.mkdir(exist_ok=True)
 with (OUT/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def txt(name,s):
 OUT.mkdir(exist_ok=True); (OUT/name).write_text(s,encoding='utf-8')
