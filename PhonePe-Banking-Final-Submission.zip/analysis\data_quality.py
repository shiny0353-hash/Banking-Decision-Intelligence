"""Reusable data-quality checks for tabular banking data."""
import pandas as pd

def profile_dataframe(df: pd.DataFrame) -> dict:
    """Return a compact profile without assuming specific column names."""
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": [str(c) for c in df.columns],
        "missing_values": df.isna().sum().astype(int).to_dict(),
        "duplicate_rows": int(df.duplicated().sum()),
        "dtypes": {str(k): str(v) for k, v in df.dtypes.items()},
    }
