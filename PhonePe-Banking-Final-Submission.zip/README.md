Domain: Banking

# PhonePe Banking Decision Intelligence

Python 3.10+ capstone using NumPy and an 800-row reproducible synthetic dataset. These are simulated accounts, not PhonePe customer records.

## Run on Windows

    py -m pip install -r requirements.txt
    py generate_data.py
    py part1.py
    py part2.py
    py part3.py
    py part4.py

Each part writes results to outputs/. The supplied text omits detailed Parts 3 and 4 criteria and original source files, so later workflows use documented baseline interpretations. Regenerated values differ from pasted examples.

## Methods

Part 1: estimation, z test, sample size, and regression. Part 2: logistic regression and threshold cost sweep (INR 200 per missed default, INR 50 per false alert). Part 3: standardized K-means and PCA. Part 4: comparison outputs and neural architecture outline.

Synthetic data are for learning only. Adapt Parts 3 and 4 to the full course rubric before submission.
